'use strict';

const request = require('request');
const trading_pair = require('./trading_pair.json');

const end_point = "https://api.cobinhood.com";
const stat = "/v1/market/stats";
const url = end_point + stat;

const match = (trading_pair, name) => trading_pair.id == name || trading_pair.pair.includes(name.toLowerCase());

function* find_trading_pair(name) {
  for (const p of trading_pair) {
    if (match(p, name)) yield p;
  }
}

function getPrice(pair) {
  return new Promise(function(resolve,reject) {
    request.get(url, function (error, response, body) {
      if (!error && response.statusCode === 200) {
        var result = JSON.parse(body)["result"][pair]["last_price"];
        resolve(result);
      }
      else {
        reject(error);
      }
    });
  });
}

exports.bot = function (req, res) {
  const update = req.body;
  if (update.hasOwnProperty('message') && update.message.hasOwnProperty('text')) {
    const pair1 = update.message.text;
    getPrice(pair1).then(
      function(x) {
        const reply = {
          method: 'sendMessage',
          chat_id: update.message.chat.id,
          text: "Current price of the trading pair\n" + update.message.text + ' ' + x
        };
        return res.json(reply);
      })
  }
  else if (update.hasOwnProperty('inline_query')) {
    const inline_query = update.inline_query;
    const name = inline_query.query
    
    const results = [];
    for (const p of find_trading_pair(name)) {
      const result = {
        type: "article",
        id: p.id,
        title: p.pair,
        input_message_content: {
          message_text: " ",
          parse_mode: "Markdown"
        }
      };
      results.push(result);
    }

    const reply = {
      method: 'answerInlineQuery',
      inline_query_id: inline_query.id,
      results: JSON.stringify(results)
    };
    return res.json(reply);
  } 
  else {
    res.status(200).send('No message defined!');
  }
};



